package main

import (
	"e-question/logger"
	"fmt"
)

func main() {
	fmt.Println(logger.New())
}
